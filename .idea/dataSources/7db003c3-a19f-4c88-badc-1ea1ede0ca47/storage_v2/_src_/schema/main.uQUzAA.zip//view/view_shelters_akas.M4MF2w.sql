CREATE VIEW view_shelters_akas as
SELECT shelters.*, shelter_akas.id as aka_id, shelter_akas.name as aka_name, shelter_akas.notes as aka_notes, shelter_akas.created as aka_created, shelter_akas.updated as aka_updated FROM shelters LEFT JOIN shelter_akas ON shelters.id = shelter_akas.shelter_id;

